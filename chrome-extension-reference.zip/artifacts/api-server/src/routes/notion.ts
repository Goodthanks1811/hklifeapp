import { Router, type IRouter } from "express";

const router: IRouter = Router();

const NOTION_VERSION = "2022-06-28";

function notionHeaders(apiKey: string) {
  return {
    "Authorization": `Bearer ${apiKey}`,
    "Notion-Version": NOTION_VERSION,
    "Content-Type": "application/json",
  };
}

// ── In-memory schema cache (5-minute TTL) ─────────────────────────────────────
const _schemaCache: Map<string, { options: string[]; type: string; ts: number }> = new Map();
const SCHEMA_TTL_MS = 5 * 60 * 1000;

async function getCategoryOptions(dbId: string, apiKey: string): Promise<{ options: string[]; type: string }> {
  const cached = _schemaCache.get(dbId);
  if (cached && Date.now() - cached.ts < SCHEMA_TTL_MS) {
    return { options: cached.options, type: cached.type };
  }
  try {
    const r = await fetch(`https://api.notion.com/v1/databases/${dbId}`, { headers: notionHeaders(apiKey) });
    if (!r.ok) return { options: [], type: "select" };
    const db = await r.json();
    const catProp = db.properties?.Category;
    const type: string = catProp?.type || "select";
    const options: string[] =
      type === "select"       ? (catProp?.select?.options       || []).map((o: any) => o.name as string) :
      type === "multi_select" ? (catProp?.multi_select?.options || []).map((o: any) => o.name as string) :
      type === "status"       ? (catProp?.status?.options       || []).map((o: any) => o.name as string) : [];
    _schemaCache.set(dbId, { options, type, ts: Date.now() });
    return { options, type };
  } catch {
    return { options: [], type: "select" };
  }
}

function extractTitle(titleProp: any): string {
  if (!titleProp) return "Untitled";
  const arr = titleProp.title || titleProp.rich_text || [];
  return arr.map((t: any) => t.plain_text).join("") || "Untitled";
}

function extractStatus(props: Record<string, any>): string {
  for (const key of Object.keys(props)) {
    const prop = props[key];
    if (prop.type === "status" && prop.status?.name) {
      return prop.status.name;
    }
    if (prop.type === "select" && prop.select?.name) {
      return prop.select.name;
    }
  }
  return "Not started";
}

function extractStatusFieldName(schema: Record<string, any>): string | null {
  for (const key of Object.keys(schema)) {
    if (schema[key].type === "status" || schema[key].type === "select") {
      return key;
    }
  }
  return null;
}

function extractPriority(props: Record<string, any>): string | undefined {
  for (const key of Object.keys(props)) {
    const lower = key.toLowerCase();
    if (lower === "priority") {
      const prop = props[key];
      if (prop.type === "select" && prop.select?.name) return prop.select.name;
    }
  }
  return undefined;
}

function extractDate(props: Record<string, any>): string | undefined {
  for (const key of Object.keys(props)) {
    const prop = props[key];
    if (prop.type === "date" && prop.date?.start) {
      return prop.date.start;
    }
  }
  return undefined;
}

function extractTags(props: Record<string, any>): string[] {
  for (const key of Object.keys(props)) {
    const prop = props[key];
    if (prop.type === "multi_select" && Array.isArray(prop.multi_select)) {
      return prop.multi_select.map((t: any) => t.name);
    }
  }
  return [];
}

function extractDescription(props: Record<string, any>): string | undefined {
  for (const key of Object.keys(props)) {
    const lower = key.toLowerCase();
    if (
      (lower === "description" || lower === "notes" || lower === "summary") &&
      props[key].type === "rich_text"
    ) {
      const arr = props[key].rich_text || [];
      const text = arr.map((t: any) => t.plain_text).join("");
      return text || undefined;
    }
  }
  return undefined;
}

router.get("/databases", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  if (!apiKey) {
    res.status(400).json({ message: "Missing Notion API key" });
    return;
  }

  try {
    const response = await fetch("https://api.notion.com/v1/search", {
      method: "POST",
      headers: notionHeaders(apiKey),
      body: JSON.stringify({ filter: { value: "database", property: "object" } }),
    });

    if (!response.ok) {
      const err = await response.json();
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }

    const data = await response.json();
    const databases = (data.results || []).map((db: any) => {
      // For database objects, title is a top-level array of rich text segments
      const titleArr: any[] = Array.isArray(db.title) ? db.title : [];
      const title = titleArr.map((t: any) => t.plain_text || "").join("").trim() || "Untitled";
      return { id: db.id, title, statuses: [] };
    });

    res.json({ databases });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to fetch Notion databases");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/tasks", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const databaseId = req.query.database_id as string;

  if (!apiKey) {
    res.status(400).json({ message: "Missing Notion API key" });
    return;
  }
  if (!databaseId) {
    res.status(400).json({ message: "Missing database_id" });
    return;
  }

  try {
    const allTasks: any[] = [];
    let cursor: string | undefined;
    let hasMore = true;

    while (hasMore) {
      const body: any = { page_size: 100 };
      if (cursor) body.start_cursor = cursor;

      const response = await fetch(
        `https://api.notion.com/v1/databases/${databaseId}/query`,
        {
          method: "POST",
          headers: notionHeaders(apiKey),
          body: JSON.stringify(body),
        }
      );

      if (!response.ok) {
        const err = await response.json();
        res.status(response.status).json({ message: err.message || "Notion error" });
        return;
      }

      const data = await response.json();
      allTasks.push(...(data.results || []));
      hasMore = data.has_more;
      cursor = data.next_cursor;
    }

    const tasks = allTasks.map((page: any) => {
      const props = page.properties || {};
      const titleProp = Object.values(props).find(
        (p: any) => p.type === "title"
      ) as any;

      return {
        id: page.id,
        title: extractTitle(titleProp),
        status: extractStatus(props),
        priority: extractPriority(props),
        dueDate: extractDate(props),
        description: extractDescription(props),
        tags: extractTags(props),
        url: page.url,
      };
    });

    res.json({ tasks });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to fetch Notion tasks");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.patch("/tasks/:taskId", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { taskId } = req.params;
  const { status } = req.body;

  if (!apiKey) {
    res.status(400).json({ message: "Missing Notion API key" });
    return;
  }
  if (!status) {
    res.status(400).json({ message: "Missing status" });
    return;
  }

  try {
    const pageRes = await fetch(`https://api.notion.com/v1/pages/${taskId}`, {
      headers: notionHeaders(apiKey),
    });

    if (!pageRes.ok) {
      const err = await pageRes.json();
      res.status(pageRes.status).json({ message: err.message || "Notion error" });
      return;
    }

    const page = await pageRes.json();
    const props = page.properties || {};

    let statusPropName: string | null = null;
    let statusPropType: string | null = null;

    for (const key of Object.keys(props)) {
      if (props[key].type === "status") {
        statusPropName = key;
        statusPropType = "status";
        break;
      }
    }
    if (!statusPropName) {
      for (const key of Object.keys(props)) {
        if (props[key].type === "select") {
          statusPropName = key;
          statusPropType = "select";
          break;
        }
      }
    }

    if (!statusPropName || !statusPropType) {
      res.status(400).json({ message: "No status property found on this page" });
      return;
    }

    const updateBody: any = {
      properties: {
        [statusPropName]:
          statusPropType === "status"
            ? { status: { name: status } }
            : { select: { name: status } },
      },
    };

    const updateRes = await fetch(`https://api.notion.com/v1/pages/${taskId}`, {
      method: "PATCH",
      headers: notionHeaders(apiKey),
      body: JSON.stringify(updateBody),
    });

    if (!updateRes.ok) {
      const err = await updateRes.json();
      res.status(updateRes.status).json({ message: err.message || "Update failed" });
      return;
    }

    res.json({ success: true });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to update Notion task");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/schema/:dbId", async (req, res) => {
  res.set("Cache-Control", "no-store");
  const apiKey = req.headers["x-notion-key"] as string;
  const { dbId } = req.params;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }
  try {
    const response = await fetch(`https://api.notion.com/v1/databases/${dbId}`, {
      headers: notionHeaders(apiKey),
    });
    if (!response.ok) {
      const err = await response.json();
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }
    const db = await response.json();
    const props = db.properties || {};
    const priProp = props["-"];
    const priType = priProp?.type || "select";
    const priOptions =
      priType === "select" ? (priProp?.select?.options || []).map((o: any) => o.name.replace(/\uFE0F/g, "")) :
      priType === "status" ? (priProp?.status?.options || []).map((o: any) => o.name.replace(/\uFE0F/g, "")) : null;
    const epicProp = props["Epic"];
    const epicType = epicProp?.type || "select";
    const epicOptions: string[] =
      epicType === "select" ? (epicProp?.select?.options || []).map((o: any) => o.name) :
      epicType === "status" ? (epicProp?.status?.options || []).map((o: any) => o.name) : [];
    const priorityProp = props["Priority"];
    const priorityType = priorityProp?.type || "select";
    const categoryProp = props["Category"];
    const categoryType = categoryProp?.type || "select";
    const categoryOptions: string[] =
      categoryType === "select"       ? (categoryProp?.select?.options       || []).map((o: any) => o.name) :
      categoryType === "multi_select" ? (categoryProp?.multi_select?.options || []).map((o: any) => o.name) :
      categoryType === "status"       ? (categoryProp?.status?.options       || []).map((o: any) => o.name) : [];
    // Find the URL-holding property: prefer "Reference", else first url-type prop
    let referencePropertyName: string | null = null;
    let referenceType: string = "url";
    if (props["Reference"]) {
      referencePropertyName = "Reference";
      referenceType = props["Reference"].type || "url";
    } else {
      for (const key of Object.keys(props)) {
        if (props[key].type === "url") { referencePropertyName = key; referenceType = "url"; break; }
      }
      if (!referencePropertyName) {
        for (const key of Object.keys(props)) {
          if (key.toLowerCase().includes("ref") || key.toLowerCase().includes("link") || key.toLowerCase().includes("url")) {
            referencePropertyName = key; referenceType = props[key].type || "rich_text"; break;
          }
        }
      }
    }
    res.json({ priType, priOptions, epicType, epicOptions, priorityType, categoryType, categoryOptions, referenceType, referencePropertyName });
  } catch (e: any) {
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/pages", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { dbId, title, epic, emoji, priType, priOptions, epicType, priorityType, category, url } = req.body;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }
  if (!dbId || !title) { res.status(400).json({ message: "Missing dbId or title" }); return; }

  const IR_PRIORITY_NOW = " ".repeat(23) + "\u2757\uFE0F Now";

  function findBest(wanted: string, options: string[] | null): string {
    if (!options) return wanted;
    const w = wanted.toLowerCase().trim();
    for (const o of options) { if (o.toLowerCase().trim() === w) return o; }
    return wanted;
  }

  try {
    const body: any = {
      parent: { database_id: dbId },
      properties: {
        Task: { title: [{ type: "text", text: { content: title } }] },
        Done: { checkbox: false },
      },
    };

    if (priorityType === "select") body.properties.Priority = { select: { name: IR_PRIORITY_NOW } };
    else if (priorityType === "status") body.properties.Priority = { status: { name: IR_PRIORITY_NOW } };

    if (category) {
      // Try select first, fall back to status — caller can pass categoryType to override
      const categoryType = req.body.categoryType || "select";
      if (categoryType === "select") body.properties.Category = { select: { name: category } };
      else if (categoryType === "status") body.properties.Category = { status: { name: category } };
    }

    if (epic) {
      if (epicType === "select") body.properties.Epic = { select: { name: epic } };
      else if (epicType === "status") body.properties.Epic = { status: { name: epic } };
    }

    if (url && typeof url === "string" && url.trim()) {
      const referenceType = req.body.referenceType || "url";
      const propName = req.body.referencePropertyName || "Reference";
      let u = url.trim();
      if (u && !u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
      if (referenceType === "files") {
        body.properties[propName] = { files: [{ type: "external", name: u, external: { url: u } }] };
      } else if (referenceType === "rich_text") {
        body.properties[propName] = { rich_text: [{ type: "text", text: { content: u, link: { url: u } } }] };
      } else {
        body.properties[propName] = { url: u };
      }
    }

    const emojiVal = String(emoji || "\uD83D\uDD25").replace(/\uFE0F/g, "");
    if (priType === "select") body.properties["-"] = { select: { name: findBest(emojiVal, priOptions) } };
    else if (priType === "status") body.properties["-"] = { status: { name: findBest(emojiVal, priOptions) } };
    else body.properties["-"] = { rich_text: [{ type: "text", text: { content: emojiVal } }] };

    const response = await fetch("https://api.notion.com/v1/pages", {
      method: "POST",
      headers: notionHeaders(apiKey),
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error("[POST /pages] Notion error:", JSON.stringify(err), "body sent:", JSON.stringify(body));
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }
    const page = await response.json();
    res.json({ success: true, id: page.id });
  } catch (e: any) {
    res.status(500).json({ message: "Internal server error" });
  }
});

// ── Footy Highlight ───────────────────────────────────────────────────────────
// POST /api/notion/footy-highlight
// Body: { dbId, player, round, team, minute, recorded? }
router.post("/footy-highlight", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { dbId, player, round, team, minute, recorded } = req.body;
  if (!apiKey)  { res.status(400).json({ message: "Missing Notion API key" }); return; }
  if (!dbId)    { res.status(400).json({ message: "Missing dbId" }); return; }
  if (!player)  { res.status(400).json({ message: "Missing player" }); return; }
  if (!team)    { res.status(400).json({ message: "Missing team" }); return; }

  try {
    const body: any = {
      parent: { database_id: dbId },
      properties: {
        Player:   { title:    [{ type: "text", text: { content: String(player).trim() } }] },
        Team:     { select:   { name: String(team) } },
        Recorded: { checkbox: recorded === true || recorded === "true" },
      },
    };
    if (round !== undefined && round !== "") body.properties.Round = { number: parseFloat(String(round)) };
    if (minute !== undefined && minute !== "") body.properties.Minute = { number: parseFloat(String(minute)) };

    const response = await fetch("https://api.notion.com/v1/pages", {
      method: "POST",
      headers: notionHeaders(apiKey),
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error("[POST /footy-highlight] Notion error:", JSON.stringify(err), "body sent:", JSON.stringify(body));
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }
    const page = await response.json();
    res.json({ success: true, id: page.id });
  } catch (e: any) {
    console.error("[POST /footy-highlight] exception:", e);
    res.status(500).json({ message: "Internal server error" });
  }
});

// ── Generic Log Entry ─────────────────────────────────────────────────────────
// POST /api/notion/log
// Body: { dbId, titleProp, titleValue, date?, notesProp?, notesValue? }
router.post("/log", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { dbId, titleProp, titleValue, date, notesProp, notesValue, areaProp, areaValue } = req.body;
  if (!apiKey)      { res.status(400).json({ message: "Missing Notion API key" }); return; }
  if (!dbId || !titleProp || !titleValue) {
    res.status(400).json({ message: "Missing dbId, titleProp or titleValue" }); return;
  }

  try {
    const today = date || new Date().toISOString().slice(0, 10);
    const body: any = {
      parent: { database_id: dbId },
      properties: {
        [titleProp]: { title: [{ type: "text", text: { content: String(titleValue) } }] },
        Date: { date: { start: today } },
      },
    };

    if (areaProp && areaValue && String(areaValue).trim()) {
      body.properties[areaProp] = { select: { name: String(areaValue) } };
    }

    if (notesProp && notesValue && String(notesValue).trim()) {
      body.properties[notesProp] = {
        rich_text: [{ type: "text", text: { content: String(notesValue) } }],
      };
      body.children = [{
        object: "block", type: "paragraph",
        paragraph: { rich_text: [{ type: "text", text: { content: String(notesValue) } }] },
      }];
    }

    const response = await fetch("https://api.notion.com/v1/pages", {
      method: "POST",
      headers: notionHeaders(apiKey),
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const err = await response.json();
      console.error("[POST /log] Notion error:", JSON.stringify(err));
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }
    const page = await response.json();
    res.json({ success: true, id: page.id });
  } catch (e: any) {
    console.error("[POST /log] error:", e.message);
    res.status(500).json({ message: "Internal server error" });
  }
});

// ── Life Tasks ────────────────────────────────────────────────────────────────
const LIFE_DB_ID = "2c8b7eba3523802abbe2e934df42a4e2";

router.get("/life-tasks", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { category } = req.query;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }

  try {
    const filterClauses: any[] = [
      { property: "Done", checkbox: { equals: false } },
    ];
    if (category) {
      const { options: catOptions, type: catType } = await getCategoryOptions(LIFE_DB_ID, apiKey);
      const needle = (category as string).trim();
      // Find ALL option variants that match after trimming (catches spacey duplicates in Notion)
      const matches = catOptions.filter(o => o.trim() === needle);
      const variants: string[] = matches.length > 0 ? matches : [category as string];
      const filterOp = catType === "multi_select" ? "contains" : "equals";
      const filterKey = catType === "multi_select" ? "multi_select" : "select";
      if (variants.length === 1) {
        filterClauses.push({ property: "Category", [filterKey]: { [filterOp]: variants[0] } });
      } else {
        filterClauses.push({ or: variants.map(v => ({ property: "Category", [filterKey]: { [filterOp]: v } })) });
      }
    }

    const body: any = {
      page_size: 100,
      filter: { and: filterClauses },
      sorts: [{ property: "Sort Order", direction: "ascending" }],
    };

    const response = await fetch(
      `https://api.notion.com/v1/databases/${LIFE_DB_ID}/query`,
      { method: "POST", headers: notionHeaders(apiKey), body: JSON.stringify(body) }
    );
    if (!response.ok) {
      const err = await response.json();
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }

    const data = await response.json();
    const tasks = (data.results || []).map((page: any) => {
      const props = page.properties || {};
      const titleArr: any[] = props.Task?.title || [];
      const title = titleArr.map((t: any) => t.plain_text).join("") || "Untitled";

      const emojiProp = props["-"];
      let emoji = "-";
      if (emojiProp?.type === "select" && emojiProp.select?.name)       emoji = emojiProp.select.name;
      else if (emojiProp?.type === "status" && emojiProp.status?.name)  emoji = emojiProp.status.name;
      else if (emojiProp?.type === "rich_text")
        emoji = (emojiProp.rich_text || []).map((t: any) => t.plain_text).join("") || "-";

      const sortOrder: number | null = props["Sort Order"]?.number ?? null;

      // Reference URL (URL-type or rich_text with link)
      let url: string | null = null;
      const refProp = props["Reference"];
      if (refProp?.type === "url") {
        url = refProp.url ?? null;
      } else if (refProp?.type === "rich_text") {
        for (const block of (refProp.rich_text || [])) {
          if (block.href)               { url = block.href;               break; }
          if (block.text?.link?.url)    { url = block.text.link.url;      break; }
        }
      }
      // Fallback: first URL-type property
      if (!url) {
        for (const key of Object.keys(props)) {
          if (props[key].type === "url" && props[key].url) { url = props[key].url; break; }
        }
      }

      const epicProp2 = props["Epic"];
      let epic: string | null = null;
      if (epicProp2?.type === "select" && epicProp2?.select?.name)       epic = epicProp2.select.name;
      else if (epicProp2?.type === "status" && epicProp2?.status?.name)  epic = epicProp2.status.name;

      // Files & media property — collect all file/external links
      const fileLinks: Array<{ name: string; url: string }> = [];
      for (const key of Object.keys(props)) {
        if (props[key].type === "files") {
          for (const file of (props[key].files || [])) {
            const fileUrl = file.type === "external" ? file.external?.url : file.file?.url;
            if (fileUrl) fileLinks.push({ name: file.name || fileUrl, url: fileUrl });
          }
        }
      }

      const created: string | null = page.created_time ?? null;
      return { id: page.id, title, emoji, sortOrder, url, epic, fileLinks: fileLinks.length > 0 ? fileLinks : null, created };
    });

    res.json({ tasks });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to fetch life tasks");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.delete("/life-tasks/:pageId", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { pageId } = req.params;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }
  try {
    const r = await fetch(`https://api.notion.com/v1/pages/${pageId}`, {
      method: "PATCH",
      headers: notionHeaders(apiKey),
      body: JSON.stringify({ archived: true }),
    });
    if (!r.ok) {
      const err = await r.json();
      res.status(r.status).json({ message: err.message || "Archive failed" });
      return;
    }
    res.json({ success: true });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to archive life task");
    res.status(500).json({ message: "Internal server error" });
  }
});

router.patch("/life-tasks/:pageId", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { pageId } = req.params;
  const { emoji, sortOrder, done, title, epic, category, categoryType } = req.body;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }

  try {
    const updateProps: any = {};

    if (title !== undefined) {
      updateProps.Task = { title: [{ type: "text", text: { content: title } }] };
    }
    if (done !== undefined) {
      updateProps.Done = { checkbox: done };
    }
    if (sortOrder !== undefined) {
      updateProps["Sort Order"] = { number: sortOrder };
    }
    if (category !== undefined && category !== null) {
      const catType = categoryType || "select";
      if (catType === "select")       updateProps.Category = { select: { name: category } };
      else if (catType === "status")  updateProps.Category = { status: { name: category } };
      else updateProps.Category = { multi_select: [{ name: category }] };
    }
    if (emoji !== undefined) {
      // Fetch the page to discover the "-" property type
      const pageRes = await fetch(`https://api.notion.com/v1/pages/${pageId}`, {
        headers: notionHeaders(apiKey),
      });
      if (pageRes.ok) {
        const page = await pageRes.json();
        const propType = page.properties?.["-"]?.type || "select";
        const clean = String(emoji).replace(/\uFE0F/g, "");
        if (propType === "select")      updateProps["-"] = { select: { name: clean } };
        else if (propType === "status") updateProps["-"] = { status: { name: clean } };
        else                            updateProps["-"] = { rich_text: [{ type: "text", text: { content: clean } }] };
      }
    }

    if (epic !== undefined && epic !== null) {
      updateProps.Epic = { select: { name: epic } };
    }

    if (Object.keys(updateProps).length === 0) { res.json({ success: true }); return; }

    const updateRes = await fetch(`https://api.notion.com/v1/pages/${pageId}`, {
      method: "PATCH",
      headers: notionHeaders(apiKey),
      body: JSON.stringify({ properties: updateProps }),
    });
    if (!updateRes.ok) {
      const err = await updateRes.json();
      res.status(updateRes.status).json({ message: err.message || "Update failed" });
      return;
    }
    res.json({ success: true });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to patch life task");
    res.status(500).json({ message: "Internal server error" });
  }
});

// ── Block ↔ markdown helpers ──────────────────────────────────────────────────

/** Convert a Notion rich_text array to a markdown string (bold / italic / underline). */
function richTextToMarkdown(richText: any[]): string {
  return (richText || []).map((seg: any) => {
    let text = seg.plain_text || "";
    const ann = seg.annotations || {};
    if (ann.bold)      text = `**${text}**`;
    if (ann.italic)    text = `*${text}*`;
    if (ann.underline) text = `__${text}__`;
    if (ann.code)      text = `\`${text}\``;
    if (ann.strikethrough) text = `~~${text}~~`;
    return text;
  }).join("");
}

/** Convert a single Notion block to a markdown line. */
function blockToMarkdownLine(block: any): string | null {
  const type: string = block.type;
  const rich: any[] = block[type]?.rich_text || block[type]?.text || [];
  const text = richTextToMarkdown(rich);
  switch (type) {
    case "heading_1":           return `# ${text}`;
    case "heading_2":           return `## ${text}`;
    case "heading_3":           return `### ${text}`;
    case "bulleted_list_item":  return `- ${text}`;
    case "numbered_list_item":  return `1. ${text}`;
    case "divider":             return "---";
    case "paragraph":           return text; // may be empty
    default:                    return text || null;
  }
}

/** Parse a markdown string segment into Notion rich_text annotations. */
function markdownToRichText(raw: string): any[] {
  const segments: any[] = [];
  // Simple greedy parser: bold > italic > underline > code > strikethrough > plain
  const re = /(\*\*(.+?)\*\*)|(\*(.+?)\*)|(\_\_(.+?)\_\_)|(`(.+?)`)|(\~\~(.+?)\~\~)|([^*_`~]+)/gs;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw)) !== null) {
    if (m[1])  { segments.push({ type:"text", text:{ content: m[2] }, annotations:{ bold:true } }); }
    else if (m[3])  { segments.push({ type:"text", text:{ content: m[4] }, annotations:{ italic:true } }); }
    else if (m[5])  { segments.push({ type:"text", text:{ content: m[6] }, annotations:{ underline:true } }); }
    else if (m[7])  { segments.push({ type:"text", text:{ content: m[8] }, annotations:{ code:true } }); }
    else if (m[9])  { segments.push({ type:"text", text:{ content: m[10] }, annotations:{ strikethrough:true } }); }
    else if (m[11]) { segments.push({ type:"text", text:{ content: m[11] } }); }
  }
  return segments.length > 0 ? segments : [{ type:"text", text:{ content: raw } }];
}

/** Convert a markdown line to a Notion block object. */
function markdownLineToBlock(line: string): any {
  if (/^###\s/.test(line)) return { type:"heading_3", heading_3:{ rich_text: markdownToRichText(line.replace(/^###\s/,"")) } };
  if (/^##\s/.test(line))  return { type:"heading_2", heading_2:{ rich_text: markdownToRichText(line.replace(/^##\s/,"")) } };
  if (/^#\s/.test(line))   return { type:"heading_1", heading_1:{ rich_text: markdownToRichText(line.replace(/^#\s/,"")) } };
  if (/^-\s/.test(line))   return { type:"bulleted_list_item", bulleted_list_item:{ rich_text: markdownToRichText(line.replace(/^-\s/,"")) } };
  if (/^\d+\.\s/.test(line)) return { type:"numbered_list_item", numbered_list_item:{ rich_text: markdownToRichText(line.replace(/^\d+\.\s/,"")) } };
  if (/^---+$/.test(line.trim())) return { type:"divider", divider:{} };
  return { type:"paragraph", paragraph:{ rich_text: markdownToRichText(line) } };
}

// ─────────────────────────────────────────────────────────────────────────────

router.get("/page-blocks/:pageId", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { pageId } = req.params;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }

  try {
    const response = await fetch(
      `https://api.notion.com/v1/blocks/${pageId}/children?page_size=100`,
      { headers: notionHeaders(apiKey) }
    );
    if (!response.ok) {
      const err = await response.json();
      res.status(response.status).json({ message: err.message || "Notion error" });
      return;
    }
    const data = await response.json();

    const lines = (data.results || [])
      .map((b: any) => blockToMarkdownLine(b))
      .filter((t: string | null) => t !== null) as string[];

    // Preserve empty paragraphs as blank lines between content
    res.json({ body: lines.join("\n") });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to fetch page blocks");
    res.status(500).json({ message: "Internal server error" });
  }
});

// Replace all blocks on a page with new markdown content
router.patch("/page-blocks/:pageId", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { pageId } = req.params;
  const { body } = req.body as { body: string };
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }

  try {
    // 1. Fetch existing block IDs then delete them one by one
    const listRes = await fetch(
      `https://api.notion.com/v1/blocks/${pageId}/children?page_size=100`,
      { headers: notionHeaders(apiKey) }
    );
    if (listRes.ok) {
      const listData = await listRes.json();
      const blockIds: string[] = (listData.results || []).map((b: any) => b.id);
      await Promise.all(
        blockIds.map(bid =>
          fetch(`https://api.notion.com/v1/blocks/${bid}`, {
            method: "DELETE",
            headers: notionHeaders(apiKey),
          })
        )
      );
    }

    // 2. Parse markdown → Notion blocks, one block per line
    const lines = (body || "").split("\n");
    const children = lines.length > 0 && lines.some(l => l.trim())
      ? lines.map(line => markdownLineToBlock(line))
      : [{ type: "paragraph", paragraph: { rich_text: [] } }];

    const appendRes = await fetch(
      `https://api.notion.com/v1/blocks/${pageId}/children`,
      {
        method: "PATCH",
        headers: notionHeaders(apiKey),
        body: JSON.stringify({ children }),
      }
    );
    if (!appendRes.ok) {
      const err = await appendRes.json();
      res.status(appendRes.status).json({ message: err.message || "Failed to update blocks" });
      return;
    }
    res.json({ success: true });
  } catch (e: any) {
    req.log?.error({ err: e }, "Failed to patch page blocks");
    res.status(500).json({ message: "Internal server error" });
  }
});

function toMonthKey(d: string | null): string | null {
  return d ? d.slice(0, 7) : null;
}
function toWeekOfMonth(d: string | null): string | null {
  if (!d) return null;
  const dt = new Date(d);
  return isNaN(dt.getTime()) ? null : "W" + Math.ceil(dt.getDate() / 7);
}
function getWeeksInMonth(key: string): number {
  const [y, m] = key.split("-").map(Number);
  return Math.ceil(new Date(y, m, 0).getDate() / 7);
}
function getVisibleWeekCount(key: string): number {
  const now = new Date();
  const cur = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const max = getWeeksInMonth(key);
  if (key < cur) return max;
  if (key === cur) return Math.min(Math.ceil(now.getDate() / 7), max);
  return 0;
}

router.get("/workload", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { database_id } = req.query;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }
  if (!database_id) { res.status(400).json({ message: "Missing database_id" }); return; }

  type WeekBucket = { created: number; done: number; createdItems: string[]; doneItems: string[] };
  type MonthWeeks = Record<string, WeekBucket>;
  type CatBucket = { created: number; done: number; doneItems: string[]; weeks: Record<string, WeekBucket> };

  try {
    const allPages: any[] = [];
    let cursor: string | undefined;
    let hasMore = true;

    while (hasMore) {
      const body: any = { page_size: 100 };
      if (cursor) body.start_cursor = cursor;
      const response = await fetch(
        `https://api.notion.com/v1/databases/${database_id}/query`,
        { method: "POST", headers: notionHeaders(apiKey), body: JSON.stringify(body) }
      );
      if (!response.ok) {
        const err = await response.json();
        res.status(response.status).json({ message: err.message || "Notion error" });
        return;
      }
      const data = await response.json();
      allPages.push(...(data.results || []));
      hasMore = data.has_more;
      cursor = data.next_cursor;
    }

    const monthData: Record<string, MonthWeeks> = {};
    const categoryMonthData: Record<string, Record<string, CatBucket>> = {};

    const ensureCat = (month: string, cat: string) => {
      if (!categoryMonthData[month]) categoryMonthData[month] = {};
      if (!categoryMonthData[month][cat]) categoryMonthData[month][cat] = { created: 0, done: 0, doneItems: [], weeks: {} };
      return categoryMonthData[month][cat];
    };
    const ensureCatWeek = (bucket: CatBucket, week: string) => {
      if (!bucket.weeks[week]) bucket.weeks[week] = { created: 0, done: 0, createdItems: [], doneItems: [] };
      return bucket.weeks[week];
    };

    for (const page of allPages) {
      const props = page.properties || {};
      const cs: string | null = props.Created?.created_time || page.created_time || null;
      const us: string | null = props.Updated?.last_edited_time || page.last_edited_time || null;
      const done = props.Done?.checkbox === true;
      const cat: string = props.Category?.type === "select"
        ? (props.Category.select?.name || "Uncategorised")
        : "Uncategorised";
      const titleArr: any[] = props.Task?.title || [];
      const title = titleArr.map((t: any) => t.plain_text || "").join("") || "Untitled";

      const cm = toMonthKey(cs);
      const cw = toWeekOfMonth(cs);
      if (cm && cw) {
        if (!monthData[cm]) monthData[cm] = {};
        if (!monthData[cm][cw]) monthData[cm][cw] = { created: 0, done: 0, createdItems: [], doneItems: [] };
        monthData[cm][cw].created++;
        monthData[cm][cw].createdItems.push(title);
        const cb = ensureCat(cm, cat);
        cb.created++;
        ensureCatWeek(cb, cw).created++;
        ensureCatWeek(cb, cw).createdItems.push(title);
      }

      if (done && us) {
        const dm = toMonthKey(us);
        const dw = toWeekOfMonth(us);
        if (dm && dw) {
          if (!monthData[dm]) monthData[dm] = {};
          if (!monthData[dm][dw]) monthData[dm][dw] = { created: 0, done: 0, createdItems: [], doneItems: [] };
          monthData[dm][dw].done++;
          monthData[dm][dw].doneItems.push(title);
          const db = ensureCat(dm, cat);
          ensureCatWeek(db, dw).done++;
          ensureCatWeek(db, dw).doneItems.push(title);
        }
        if (dm) {
          const db = ensureCat(dm, cat);
          db.done++;
          db.doneItems.push(title);
        }
      }
    }

    // Fill missing weeks
    for (const mk of Object.keys(monthData)) {
      for (let w = 1; w <= getWeeksInMonth(mk); w++) {
        const wk = `W${w}`;
        if (!monthData[mk][wk]) monthData[mk][wk] = { created: 0, done: 0, createdItems: [], doneItems: [] };
      }
    }

    const sortedKeys = Object.keys(monthData).sort();

    const months = sortedKeys.map((key) => {
      const visibleCount = getVisibleWeekCount(key);
      const visibleWeeks = Array.from({ length: visibleCount }, (_, i) => `W${i + 1}`);
      const weeks = monthData[key];
      const tc = visibleWeeks.reduce((a, w) => a + (weeks[w]?.created || 0), 0);
      const td = visibleWeeks.reduce((a, w) => a + (weeks[w]?.done || 0), 0);
      const maxWeekVal = Math.max(1, ...visibleWeeks.map((w) => Math.max(weeks[w]?.created || 0, weeks[w]?.done || 0)));
      const [y, m] = key.split("-").map(Number);
      const label = new Date(y, m - 1, 1).toLocaleString("en-US", { month: "long", year: "numeric" });
      const catEntries = Object.entries(categoryMonthData[key] || {})
        .sort((a, b) => (b[1].created + b[1].done) - (a[1].created + a[1].done))
        .slice(0, 8);
      const maxCatVal = Math.max(1, ...catEntries.map(([, v]) => Math.max(v.created, v.done)));
      return {
        key, label, totalCreated: tc, totalDone: td, maxWeekVal,
        visibleWeeks,
        weeks: Object.fromEntries(
          Object.entries(weeks).map(([k, v]) => [k, {
            created: v.created, done: v.done,
            createdItems: v.createdItems, doneItems: v.doneItems,
          }])
        ),
        categories: catEntries.map(([name, v]) => ({
          name, created: v.created, done: v.done, doneItems: v.doneItems,
          weeks: v.weeks,
        })),
        maxCatVal,
      };
    });

    res.json({ months });
  } catch (e: any) {
    res.status(500).json({ message: "Internal server error" });
  }
});

const MOOD_ORDER = ["Awesome", "Good", "Meh", "Tired", "Low", "Stressed"];

router.get("/moods", async (req, res) => {
  const apiKey = req.headers["x-notion-key"] as string;
  const { database_id } = req.query;
  if (!apiKey) { res.status(400).json({ message: "Missing Notion API key" }); return; }
  if (!database_id) { res.status(400).json({ message: "Missing database_id" }); return; }

  try {
    const allPages: any[] = [];
    let cursor: string | undefined;
    let hasMore = true;

    while (hasMore) {
      const body: any = {
        page_size: 100,
        sorts: [{ property: "Date", direction: "ascending" }],
      };
      if (cursor) body.start_cursor = cursor;

      const response = await fetch(
        `https://api.notion.com/v1/databases/${database_id}/query`,
        { method: "POST", headers: notionHeaders(apiKey), body: JSON.stringify(body) }
      );

      if (!response.ok) {
        const err = await response.json();
        res.status(response.status).json({ message: err.message || "Notion error" });
        return;
      }

      const data = await response.json();
      allPages.push(...(data.results || []));
      hasMore = data.has_more;
      cursor = data.next_cursor;
    }

    const months: Record<string, Record<string, number>> = {};

    for (const page of allPages) {
      const props = page.properties || {};
      const titleArr = (props.Mood?.title || []) as any[];
      const raw = titleArr.map((t: any) => t.plain_text).join("").trim();
      if (!raw) continue;

      let mood: string | null = null;
      for (const m of MOOD_ORDER) {
        if (raw.toLowerCase().includes(m.toLowerCase())) { mood = m; break; }
      }
      if (!mood) mood = raw.replace(/[^\w\s]/gu, "").trim() || null;
      if (!mood) continue;

      const dateStr = props.Date?.date?.start;
      if (!dateStr) continue;
      const d = new Date(dateStr);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (!months[key]) months[key] = {};
      months[key][mood] = (months[key][mood] || 0) + 1;
    }

    const sortedKeys = Object.keys(months).sort();
    res.json({ months: sortedKeys.map((key) => ({ key, counts: months[key] })) });
  } catch (e: any) {
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
